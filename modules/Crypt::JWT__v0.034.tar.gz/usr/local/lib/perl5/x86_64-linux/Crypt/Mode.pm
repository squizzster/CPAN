package Crypt::Mode;

use strict;
use warnings;
our $VERSION = '0.074';

### not used

1;

=pod

=head1 NAME

Crypt::Mode - [internal only]

=cut
