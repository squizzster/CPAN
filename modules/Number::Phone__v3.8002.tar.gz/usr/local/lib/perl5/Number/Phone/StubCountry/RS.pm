# automatically generated file, don't edit



# Copyright 2011 David Cantrell, derived from data from libphonenumber
# http://code.google.com/p/libphonenumber/
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
package Number::Phone::StubCountry::RS;
use base qw(Number::Phone::StubCountry);

use strict;
use warnings;
use utf8;
our $VERSION = 1.20211206222447;

my $formatters = [
                {
                  'format' => '$1 $2',
                  'leading_digits' => '
            (?:
              2[389]|
              39
            )0|
            [7-9]
          ',
                  'national_rule' => '0$1',
                  'pattern' => '(\\d{3})(\\d{3,9})'
                },
                {
                  'format' => '$1 $2',
                  'leading_digits' => '[1-36]',
                  'national_rule' => '0$1',
                  'pattern' => '(\\d{2})(\\d{5,10})'
                }
              ];

my $validators = {
                'fixed_line' => '
          (?:
            11[1-9]\\d|
            (?:
              2[389]|
              39
            )(?:
              0[2-9]|
              [2-9]\\d
            )
          )\\d{3,8}|
          (?:
            1[02-9]|
            2[0-24-7]|
            3[0-8]
          )[2-9]\\d{4,9}
        ',
                'geographic' => '
          (?:
            11[1-9]\\d|
            (?:
              2[389]|
              39
            )(?:
              0[2-9]|
              [2-9]\\d
            )
          )\\d{3,8}|
          (?:
            1[02-9]|
            2[0-24-7]|
            3[0-8]
          )[2-9]\\d{4,9}
        ',
                'mobile' => '
          6(?:
            [0-689]|
            7\\d
          )\\d{6,7}
        ',
                'pager' => '',
                'personal_number' => '',
                'specialrate' => '(
          (?:
            78\\d|
            90[0169]
          )\\d{3,7}
        )|(7[06]\\d{4,10})',
                'toll_free' => '800\\d{3,9}',
                'voip' => ''
              };
my %areanames = ();
$areanames{en} = {"38111", "Belgrade",
"38129", "Prizren",
"381390", "Dakovica",
"38110", "Pirot",
"38112", "Pozarevac",
"38118", "Nis",
"38137", "Krusevac",
"38116", "Leskovac",
"38115", "Sabac",
"38127", "Prokuplje",
"38113", "Pancevo",
"38114", "Valjevo",
"381290", "Urosevac",
"38139", "Pec",
"38126", "Smederevo",
"38125", "Sombor",
"38132", "Cacak",
"38117", "Vranje",
"381280", "Gnjilane",
"38138", "Pristina",
"38123", "Zrenjanin",
"38131", "Uzice",
"38124", "Subotica",
"38130", "Bor",
"38134", "Kragujevac",
"381230", "Kikinda",
"38121", "Novi\ Sad",
"38133", "Prijepolje",
"38119", "Zajecar",
"38120", "Novi\ Pazar",
"38122", "Sremska\ Mitrovica",
"38135", "Jagodina",
"38136", "Kraljevo",
"38128", "Kosovska\ Mitrovica",};
$areanames{sr} = {"38135", "Јагодина",
"38136", "Краљево",
"38122", "Сремска\ Митровица",
"38128", "Косовска\ Митровица",
"38133", "Пријепоље",
"381230", "Кикинда",
"38134", "Крагујевац",
"38121", "Нови\ Сад",
"38120", "Нови\ Пазар",
"38119", "Зајечар",
"38131", "Ужице",
"38124", "Суботица",
"38123", "Зрењанин",
"38130", "Бор",
"38132", "Чачак",
"38126", "Смедерево",
"38125", "Сомбор",
"38138", "Приштина",
"38117", "Врање",
"381280", "Гњилане",
"38114", "Ваљево",
"38113", "Панчево",
"38139", "Пећ",
"381290", "Урошевац",
"38116", "Лесковац",
"38115", "Шабац",
"38127", "Прокупље",
"38112", "Пожаревац",
"38137", "Крушевац",
"38118", "Ниш",
"38111", "Београд",
"381390", "Ђаковица",
"38110", "Пирот",
"38129", "Призрен",};

    sub new {
      my $class = shift;
      my $number = shift;
      $number =~ s/(^\+381|\D)//g;
      my $self = bless({ number => $number, formatters => $formatters, validators => $validators, areanames => \%areanames}, $class);
      return $self if ($self->is_valid());
      $number =~ s/^(?:0)//;
      $self = bless({ number => $number, formatters => $formatters, validators => $validators, areanames => \%areanames}, $class);
      return $self->is_valid() ? $self : undef;
    }
1;