package LWP::DebugFile;

our $VERSION = '6.59';

# legacy stub

1;
